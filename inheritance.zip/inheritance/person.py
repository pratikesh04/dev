class ClassPerson:
	def getName(self):
		return input("Enter your name")
	def getAge(self):
		return int(input("Enter your age"))

